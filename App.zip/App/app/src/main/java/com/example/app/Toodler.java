package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Toodler extends AppCompatActivity {

    public TextView q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,res;
    public RadioGroup r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
    public RadioButton a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
    public Button predict;
    String url="http://127.0.0.1:5000/predict";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toodler);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);
        r4=findViewById(R.id.r4);
        r5=findViewById(R.id.r5);
        r6=findViewById(R.id.r6);
        r7=findViewById(R.id.r7);
        r8=findViewById(R.id.r8);
        r9=findViewById(R.id.r9);
        r10=findViewById(R.id.r10);
        res=findViewById(R.id.res);
        predict=findViewById(R.id.predict);
        predict.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int id1=r1.getCheckedRadioButtonId();
                    a1=findViewById(id1);
                    if(a1.getText().equals("Yes")){
                        String a1="1";
                    }
                    else{
                        String a1="0";
                    }
                    int id2=r2.getCheckedRadioButtonId();
                    a2=findViewById(id2);
                    if(a2.getText().equals("Yes")){
                        String a2="1";
                    }
                    else{
                        String a2="0";
                    }
                    int id3=r3.getCheckedRadioButtonId();
                    a3=findViewById(id3);
                    if(a3.getText().equals("Yes")){
                        String a3="1";
                    }
                    else{
                        String a3="0";
                    }
                    int id4=r4.getCheckedRadioButtonId();
                    a4=findViewById(id4);
                    if(a4.getText().equals("Yes")){
                        String a4="1";
                    }
                    else{
                        String a4="0";
                    }
                    int id5=r5.getCheckedRadioButtonId();
                    a5=findViewById(id5);
                    if(a5.getText().equals("Yes")){
                        String a5="1";
                    }
                    else{
                        String a5="0";
                    }
                    int id6=r6.getCheckedRadioButtonId();
                    a6=findViewById(id6);
                    if(a6.getText().equals("Yes")){
                        String a6="1";
                    }
                    else{
                        String a6="0";
                    }
                    int id7=r7.getCheckedRadioButtonId();
                    a7=findViewById(id7);
                    if(a7.getText().equals("Yes")){
                        String a7="1";
                    }
                    else{
                        String a7="0";
                    }
                    int id8=r8.getCheckedRadioButtonId();
                    a8=findViewById(id8);
                    if(a8.getText().equals("Yes")){
                        String a8="1";
                    }
                    else{
                        String a8="0";
                    }
                    int id9=r9.getCheckedRadioButtonId();
                    a9=findViewById(id9);
                    if(a9.getText().equals("Yes")){
                        String a9="1";
                    }
                    else{
                        String a9="0";
                    }
                    int id10=r10.getCheckedRadioButtonId();
                    a10=findViewById(id10);
                    if(a10.getText().equals("Yes")){
                        String a10="1";
                    }
                    else{
                        String a10="0";
                    }
            StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String data = jsonObject.getString("Class");
                        if (data.equals("Yes") || (data.equals("YES"))) {
                            res.setText("ASD Detected");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }
            ){
                        @Override
                protected Map<String,String> getParams(){
                            Map<String,String>params=new HashMap<String,String>();
                            params.put("a1",a1.getText().toString());
                            params.put("a2",a2.getText().toString());
                            params.put("a3",a3.getText().toString());
                            params.put("a4",a4.getText().toString());
                            params.put("a5",a5.getText().toString());
                            params.put("a6",a6.getText().toString());
                            params.put("a7",a7.getText().toString());
                            params.put("a8",a8.getText().toString());
                            params.put("a9",a9.getText().toString());
                            params.put("a10",a10.getText().toString());

                            return params;

                        }
            };
                    RequestQueue queue= Volley.newRequestQueue(Toodler.this);
                    queue.add(stringRequest);


        }
            });

    }
}