package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    Button Login;
    TextView cacc;
    EditText inputEmail,inputcr;
    String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    ProgressDialog ProgressDialog;
    FirebaseAuth mAuth;
    FirebaseUser uAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Login=findViewById(R.id.Login);
        cacc=findViewById(R.id.cacc);
        inputEmail=findViewById(R.id.inputEmail);
        inputcr=findViewById(R.id.inputcr);
        ProgressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        uAuth=mAuth.getCurrentUser();
        cacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,Register.class);
                startActivity(i);
            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                perforLogin();
            }
        });
    }

    private void perforLogin() {
        String email= inputEmail.getText().toString();
        String Password=inputcr.getText().toString();

        if(!email.matches(emailPattern)){
            inputEmail.setError("Enter Valid Email");
        }else if(Password.isEmpty()||Password.length()<5){
            inputcr.setError("Create Valid Password");
        }else{
            ProgressDialog.setMessage("Login....");
            ProgressDialog.setTitle("Login");
            ProgressDialog.setCanceledOnTouchOutside(false);
            ProgressDialog.show();
            mAuth.signInWithEmailAndPassword(email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        ProgressDialog.dismiss();
                        sendUserTonextActivity();
                        Toast.makeText(MainActivity.this,"Login Succesful",Toast.LENGTH_SHORT).show();

                    }else{
                        ProgressDialog.dismiss();
                        Toast.makeText(MainActivity.this,""+task.getException(),Toast.LENGTH_SHORT).show();
                    }
                }
                private void sendUserTonextActivity() {
                    Intent i = new Intent(MainActivity.this, Menu.class);
                    startActivity(i);
                }
            });
    }

}


    }