package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Adult extends AppCompatActivity {
    public TextView q1,q2,q3,q4,q5,q6,q7,q8,q9,q10;;
    public RadioGroup r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
    public RadioButton a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
    public Button predict;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adult);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);
        r4=findViewById(R.id.r4);
        r5=findViewById(R.id.r5);
        r6=findViewById(R.id.r6);
        r7=findViewById(R.id.r7);
        r8=findViewById(R.id.r8);
        r9=findViewById(R.id.r9);
        r10=findViewById(R.id.r10);
        predict=findViewById(R.id.predict);
        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id1=r1.getCheckedRadioButtonId();
                a1=findViewById(id1);
                if(a1.getText().equals("Yes")){
                    String a1="1";
                }
                else{
                    String a1="0";
                }
                int id2=r2.getCheckedRadioButtonId();
                a2=findViewById(id2);
                if(a2.getText().equals("Yes")){
                    String a2="1";
                }
                else{
                    String a2="0";
                }
                int id3=r3.getCheckedRadioButtonId();
                a3=findViewById(id3);
                if(a3.getText().equals("Yes")){
                    String a3="1";
                }
                else{
                    String a3="0";
                }
                int id4=r4.getCheckedRadioButtonId();
                a4=findViewById(id4);
                if(a4.getText().equals("Yes")){
                    String a4="1";
                }
                else{
                    String a4="0";
                }
                int id5=r5.getCheckedRadioButtonId();
                a5=findViewById(id5);
                if(a5.getText().equals("Yes")){
                    String a5="1";
                }
                else{
                    String a5="0";
                }
                int id6=r6.getCheckedRadioButtonId();
                a6=findViewById(id6);
                if(a6.getText().equals("Yes")){
                    String a6="1";
                }
                else{
                    String a6="0";
                }
                int id7=r7.getCheckedRadioButtonId();
                a7=findViewById(id7);
                if(a7.getText().equals("Yes")){
                    String a7="1";
                }
                else{
                    String a7="0";
                }
                int id8=r8.getCheckedRadioButtonId();
                a8=findViewById(id8);
                if(a8.getText().equals("Yes")){
                    String a8="1";
                }
                else{
                    String a8="0";
                }
                int id9=r9.getCheckedRadioButtonId();
                a9=findViewById(id9);
                if(a9.getText().equals("Yes")){
                    String a9="1";
                }
                else{
                    String a9="0";
                }
                int id10=r10.getCheckedRadioButtonId();
                a10=findViewById(id10);
                if(a10.getText().equals("Yes")){
                    String a10="1";
                }
                else{
                    String a10="0";
                }

            }
        });
    }
}