package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Child extends AppCompatActivity {
    public TextView q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,txt;
    public RadioGroup r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
    public RadioButton a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
    public Button predict;
    double c1,c2,c3,c4,c5,c6,c7,c8,c9,c10;
    double ans;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        r3=findViewById(R.id.r3);
        r4=findViewById(R.id.r4);
        r5=findViewById(R.id.r5);
        r6=findViewById(R.id.r6);
        r7=findViewById(R.id.r7);
        r8=findViewById(R.id.r8);
        r9=findViewById(R.id.r9);
        r10=findViewById(R.id.r10);
        txt=findViewById(R.id.txt);
        predict=findViewById(R.id.predict);
        predict.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                int id1=r1.getCheckedRadioButtonId();
                a1=findViewById(id1);

               if (a1.getText().equals("Yes")){
                       c1=1.0;

                }
                else{
                    c1=0.0;
                }
                int id2=r2.getCheckedRadioButtonId();
                a2=findViewById(id2);
                if(a2.getText().equals("Yes")){
                   c2=1.0;
                }
                else{
                     c2=0.0;
                }
                int id3=r3.getCheckedRadioButtonId();
                a3=findViewById(id3);
                if(a3.getText().equals("Yes")){
                    c3=1.0;
                }
                else{
                    c3=0.0;
                }
                int id4=r4.getCheckedRadioButtonId();
                a4=findViewById(id4);
                if(a4.getText().equals("Yes")){
                     c4=1.0;
                }
                else{
                    c4=0.0;
                }
                int id5=r5.getCheckedRadioButtonId();
                a5=findViewById(id5);
                if(a5.getText().equals("Yes")){
                     c5=1.0;
                }
                else{
                         c5=0.0;
                }
                int id6=r6.getCheckedRadioButtonId();
                a6=findViewById(id6);
                if(a6.getText().equals("Yes")){
                     c6=1.0;
                }
                else{
                     c6=0.0;
                }
                int id7=r7.getCheckedRadioButtonId();
                a7=findViewById(id7);
                if(a7.getText().equals("Yes")){
                       c7=1.0;
                }
                else{
                     c7=0.0;
                }
                int id8=r8.getCheckedRadioButtonId();
                a8=findViewById(id8);
                if(a8.getText().equals("Yes")){
                    c8=1.0;
                }
                else{
                      c8=0.0;
                }
                int id9=r9.getCheckedRadioButtonId();
                a9=findViewById(id9);
                if(a9.getText().equals("Yes")){
                     c9=1.0;
                }
                else{
                       c9=0.0;
                }
                int id10=r10.getCheckedRadioButtonId();
                a10=findViewById(id10);
                if(a10.getText().equals("Yes")){
                     c10=1.0;
                }
                else{
                      c10=0.0;
                }
                double ans=(c1+c2+c3+c4+c5+c6+c7+c8+c9+c10)/10;
                if(ans>=0.5){

                    Toast.makeText(Child.this, "ASD Detected", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(Child.this, "ASD Not Detected", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}