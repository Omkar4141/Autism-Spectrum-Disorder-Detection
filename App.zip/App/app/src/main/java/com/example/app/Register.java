package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity {
 TextView alreadyacc;
 Button reg;
 EditText inputEmail,inputconp,inputcr;
 String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
 ProgressDialog ProgressDialog;
 FirebaseAuth mAuth;
 FirebaseUser uAuth;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        alreadyacc=findViewById(R.id.alreadyacc);
        reg=findViewById(R.id.reg);
        inputEmail=findViewById(R.id.inputEmail);
        inputconp=findViewById(R.id.inputconp);
        inputcr=findViewById(R.id.inputcr);
        ProgressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        uAuth=mAuth.getCurrentUser();
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                perforAuth();


            }

            private void perforAuth() {
                String email= inputEmail.getText().toString();
                String Password=inputcr.getText().toString();
                String cPassword=inputconp.getText().toString();
                if(!email.matches(emailPattern)){
                    inputEmail.setError("Enter Valid Email");
                }else if(Password.isEmpty()||Password.length()<5){
                    inputcr.setError("Create Valid Password");
                }else if(!Password.equals(cPassword)){
                    inputconp.setError("Password Dosent Match");
                }else{
                    ProgressDialog.setMessage("Regestration....");
                    ProgressDialog.setTitle("");
                    ProgressDialog.setCanceledOnTouchOutside(false);
                    ProgressDialog.show();
                    mAuth.createUserWithEmailAndPassword(email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                ProgressDialog.dismiss();
                                sendUserTonextActivity();
                                Toast.makeText(Register.this,"Register",Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                ProgressDialog.dismiss();
                                Toast.makeText(Register.this,""+task.getException(),Toast.LENGTH_SHORT).show();
                            }
                        }

                        private void sendUserTonextActivity() {
                            Intent i=new Intent(Register.this,Menu.class);
                            startActivity(i);
                        }
                    });
                }
            }
        });


        alreadyacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Register.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

    }

}